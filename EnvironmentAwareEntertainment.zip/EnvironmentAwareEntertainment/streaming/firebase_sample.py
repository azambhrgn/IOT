from firebase_streaming import Firebase
import json


def cinematic_mode_observer(x):
    data = json.loads(x[1])
    print 'data=', data

    if data['path'] == '/cinematicMode':
        print 'newValue=', data['data']


if __name__ == "__main__":
    f = Firebase("https://torrid-fire-3146.firebaseio.com/")
    callback = f.child("settings").listener(cinematic_mode_observer)
    callback.start()
    raw_input('press enter to exit...')
    callback.stop()
